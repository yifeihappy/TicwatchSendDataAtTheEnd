Ticwear API使用样例代码
